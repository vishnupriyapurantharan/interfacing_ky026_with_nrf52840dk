#ifndef _KY026_H_
#define _KY026_H_


class ky026{
	public:
		ky026();
		~ky026();
		//static int adc_channel();
		//static int adc_sequence_1();
		
};


	
#endif